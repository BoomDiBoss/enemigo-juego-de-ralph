extends CharacterBody2D

@export var max_health: int = 100
@export var speed: float = 70.0
@export var damage: int = 10

var health: int
var player: Node2D
var can_attack = true
var attacking: bool = false

func _ready():
	health = max_health
	player = get_tree().get_first_node_in_group("player")

	$AttackCooldown.timeout.connect(_on_attack_cooldown_timeout)
	$Hurtbox.area_entered.connect(_on_hurtbox_area_entered)


func _physics_process(_delta):
	if not is_instance_valid(player):
		return

func _on_attack_cooldown_timeout() -> void:
	can_attack = true


func _on_hurtbox_area_entered(area: Area2D) -> void:
	if area.is_in_group("player_attack"):
		take_damage(10)


func take_damage(amount: int) -> void:
	health -= amount

	if health <= 0:
		queue_free()

@export var slam_jump_force = -460.0
@export var slam_damage = 25

func body_slam():
	attacking = true
	velocity.x = 0

	$AnimatedSprite2D.play("prepare_slam")
	await get_tree().create_timer(0.45).timeout

	if not is_instance_valid(player):
		attacking = false
		return

	var distance = clamp(
		player.global_position.x - global_position.x,
		-110.0,
		110.0
	)

	velocity.x = clamp(distance * 1.5, -160.0, 160.0)
	velocity.y = slam_jump_force

	$AnimatedSprite2D.play("slam_air")

	# Esperar a que despegue
	while is_on_floor():
		await get_tree().physics_frame

	# Esperar a que caiga al suelo
	while not is_on_floor():
		await get_tree().physics_frame

	velocity.x = 0
	$AnimatedSprite2D.play("slam_hit")

	$SlamArea.monitoring = true
	await get_tree().physics_frame

	for body in $SlamArea.get_overlapping_bodies():
		if body.is_in_group("player"):
			if body.has_method("take_damage"):
				body.take_damage(slam_damage)

	$SlamArea.monitoring = false

	$AnimatedSprite2D.play("recover")
	await get_tree().create_timer(0.45).timeout

	$AnimatedSprite2D.play("idle")
	attacking = false
